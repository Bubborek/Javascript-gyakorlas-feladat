# Feladatok:

## main.js
1. Torolje a teljes lokali tarolo tartalmat 
2. Keszitesen fuggvenyt `validatePassword(password)` neven, mely a jelszo hosszat minimum 8 karakterben hatarozza meg (password.lenght < 8 > window.prompt)
3. Keszitesen fuggvenyt `validateUsername(username)` neven, mely a felhasznalonev hosszat minimum 3 karakterben hatarozza meg
4. Keszitsen fuggvenyt `getNextUserId()`neven melynek mukodese a kovetkezo
    * Lekeri a lokalis tarolobol a `currentUserId` kulcshoz tartozo erteket
    * Ha az ertek `null` akkor be allitja az erteket 0-ra, elenkezo esetben at alakitja szamma az erteket
    * Hozza ad egyet az aktualis ertekhez
    * Vissza tolti az erteket a lokalis taroloba a `currentUserId` kulcsra
    * Vissza adja a felhasznalo azonositot
5. Keszitsen egy adatszerkezetet mely a lokalis tarolo `users` kulcsabol szedi az ertekeit, ha a tarolo ures akkor hozzon letre egy array-t

6. Keszitesen fuggvenyt `register()` neven, amely a kovetkezo keppen mukodik
    * Lekeri az email, a username es a password DOM-ok erteket.
    * Letrehozz egy objektumot a kovetkezo keppen:
        * id: felhasznalja a `getNextUserId()` fuggvenyt
        * email : a bekert email cimet tarolja
        * password : a bekert jelszot tarolja
        * username : a bekert felhasznalo nevet tarolja
    * Ellenorzi a jelszo es a felhasznalo nev hitelesseget ha hiteles akkor hozza adja a `users` adatszerkezethez es ezt a lokalis taroloban eltarolja a `users` kulcson. Ha az adatok nem hitelesek akkor egy hiba uzenetet add vissza.

7. Kerje le a gombot majd vegezze el rajta a kovetkezo modositasokat (aszinkron megkozelites kell):
    * Az alveto esemeny kezelo funkciojat kapcsolja ki
    * Hivja meg a `register()` fugvenyt.
    * Torolje az input mezok tartalmat

8. Hozzon letre admin felhasznalot a kovetkezo keppen: 
    * email: admin@blathy.info
    * password: Almaecet
    * A letrehozott fehasznalot a lokalis tarolo `admin` kulcsan tarolja el

## login.js
1. Kerje le a lokalis tarolo admin kulcsahoz tartozo objektumot
2. Keszitsen fuggvenyt `login()` neven melynek a mukodese a kovetkezo:
    * Lekeri az email es a password inputmezok erteket
    * Megvizsgalja, hogy a be erkezett ertekek megegyeznek-e az Admin felhasznalo ertekeivel. Ha egyeznek akkor atnavigal az `admin_dashboard.html` fajra. Ha nincs egyezes egyhiba uzenetet jelenit meg.
3. Kerje le a gombot majd vegezze el rajta a kovetkezo modositasokat (aszinkron megkozelites kell):
    * Az alapveto esemeny kezelo funkciojat kapcsolja ki.
    * Hivja meg a `login()` fugvenyt.

## admin.js
1. Kerje le a lokalis tarolo `users` kulcsahoz tartozo objektumot
2. Keszitsen egy sotet megjelenesu csikozott tablazatot melyet az erre a celre letrehozott container-ben elhelyez.
