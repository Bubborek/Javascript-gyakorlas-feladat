var adminObject = localStorage.getItem('admin');
if(adminObject) {
    adminObject = JSON.parse(adminObject);
} else {
    console.log("Nincs 'admin' kulcs.");
}
function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    if (email === admin.email && password === admin.password) {
        window.location.href = 'admin_dashboard.html';
    } else {
        alert('Hibás email vagy jelszó!');
    }
}
const loginButton = document.getElementById('loginButton');
loginButton.removeEventListener('click', login);
login();
 