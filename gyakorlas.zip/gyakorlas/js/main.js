localStorage.clear();
function validatePassword(password){
return password.length >= 8;
}
function validateUsername(username){
    return username.length >= 3;
    }
function getNextId(){
    let currentUserId = localStorage.getItem('currentUserid');
    if (currentUserId === null){
        currentUserId = 0;

    }
    else{
        currentUserId = parseInt(currentUserId);
    }
    currentUserId++;
    localStorage.setItem('currentUserId', currentUserId);
    return currentUserId;
}
let users = JSON.parse(localStorage.getItem('users')) || [];
function register() {
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    if (!validatePassword(password)) {
        return alert('Hiba: A jelszónak legalább 8 karakter hosszúnak kell lennie.');
    }
    if (!validateUsername(username)) {
        return alert('Hiba: A felhasználónévnek legalább 3 karakter hosszúnak kell lennie.');
    }
    const newUser = {
        id: getNextUserId(),
        email: email,
        password: password,
        username: username
    };
    let users = getUsers();
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    alert('Sikeres regisztráció!');
 }
 document.getElementById('registerButton').addEventListener('click', async function (event) {
    event.preventDefault();
    await register();
    document.getElementById('email').value = '';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
 });
 const adminUser = {
    email: 'admin@blathy.info',
    password: 'Almaecet'
 };
 localStorage.setItem('admin', JSON.stringify(adminUser));
